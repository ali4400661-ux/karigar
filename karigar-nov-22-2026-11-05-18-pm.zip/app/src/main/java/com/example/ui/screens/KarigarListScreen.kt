package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Chat
import androidx.compose.material.icons.rounded.BookmarkAdd
import androidx.compose.material.icons.rounded.Call
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.LocationOn
import androidx.compose.material.icons.rounded.PersonSearch
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.model.KarachiConstants
import com.example.model.KarigarProfile
import com.example.model.UiState
import com.example.model.UserProfile
import com.example.ui.components.EmptyStateView
import com.example.ui.components.ErrorStateView
import com.example.ui.components.LoadingStateView
import com.example.ui.theme.EmeraldAccent
import com.example.ui.theme.EmeraldBright
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.GoldBright
import com.example.ui.theme.GoldContainer
import com.example.ui.theme.MidnightBackground
import com.example.ui.theme.OnGold
import com.example.ui.theme.SlateBorder
import com.example.ui.theme.SlateCard
import com.example.ui.theme.SlateCardElevated
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.KarigarViewModel
import com.example.util.ContactIntents

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun KarigarListScreen(
    categoryName: String,
    viewModel: KarigarViewModel,
    userProfile: UserProfile,
    snackbarHostState: SnackbarHostState,
    onBack: () -> Unit,
    onEditProfileShortcut: () -> Unit
) {
    BackHandler(onBack = onBack)

    val karigarsState by viewModel.filteredKarigarsState.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedArea by viewModel.selectedAreaFilter.collectAsStateWithLifecycle()
    val isRefreshing by viewModel.isRefreshing.collectAsStateWithLifecycle()
    val actionInProgress by viewModel.actionInProgress.collectAsStateWithLifecycle()

    var bookingTarget by remember { mutableStateOf<KarigarProfile?>(null) }

    Scaffold(
        containerColor = MidnightBackground,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        topBar = {
            Surface(color = SlateCard, tonalElevation = 2.dp) {
                Column {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .statusBarsPadding()
                            .padding(horizontal = 8.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = onBack,
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("back_to_categories_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                                contentDescription = "Back to Categories",
                                tint = TextPrimary
                            )
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = categoryName,
                                style = MaterialTheme.typography.titleLarge,
                                color = TextPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "Karachi Directory • $selectedArea",
                                style = MaterialTheme.typography.bodySmall,
                                color = GoldBright,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                    HorizontalDivider(color = SlateBorder)
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .navigationBarsPadding(),
            contentAlignment = Alignment.TopCenter
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 720.dp)
            ) {
                // Search Bar
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = viewModel::updateSearchQuery,
                    placeholder = {
                        Text(
                            text = "Search by Karigar name or area / gali...",
                            color = TextMuted
                        )
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Rounded.Search,
                            contentDescription = null,
                            tint = GoldAccent
                        )
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { viewModel.updateSearchQuery("") }) {
                                Icon(
                                    imageVector = Icons.Rounded.Close,
                                    contentDescription = "Clear search",
                                    tint = TextSecondary
                                )
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GoldAccent,
                        unfocusedBorderColor = SlateBorder,
                        focusedContainerColor = SlateCard,
                        unfocusedContainerColor = SlateCard,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                        .testTag("karigar_search_input")
                )

                // Karachi Area Filter Chips
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 10.dp)
                ) {
                    items(KarachiConstants.AREA_FILTERS) { area ->
                        val isSelected = area == selectedArea
                        FilterChip(
                            selected = isSelected,
                            onClick = { viewModel.updateAreaFilter(area) },
                            label = {
                                Text(
                                    text = area,
                                    style = MaterialTheme.typography.labelMedium
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = GoldAccent,
                                selectedLabelColor = OnGold,
                                containerColor = SlateCard,
                                labelColor = TextSecondary
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = isSelected,
                                borderColor = SlateBorder,
                                selectedBorderColor = GoldAccent
                            ),
                            modifier = Modifier.testTag("area_filter_$area")
                        )
                    }
                }

                // Karigar List with Pull-To-Refresh
                PullToRefreshBox(
                    isRefreshing = isRefreshing,
                    onRefresh = { viewModel.refreshKarigars() },
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                ) {
                    when (val state = karigarsState) {
                        is UiState.Loading -> LoadingStateView("Finding $categoryName in $selectedArea...")
                        is UiState.Error -> {
                            Box(modifier = Modifier.padding(16.dp)) {
                                ErrorStateView(
                                    message = state.message,
                                    onRetry = { viewModel.refreshKarigars() }
                                )
                            }
                        }
                        is UiState.Success -> {
                            if (state.data.isEmpty()) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .verticalScroll(rememberScrollState())
                                        .padding(16.dp)
                                ) {
                                    EmptyStateView(
                                        icon = Icons.Rounded.PersonSearch,
                                        title = "No $categoryName Found",
                                        subtitle = if (selectedArea != "All Karachi" || searchQuery.isNotBlank()) {
                                            "Is filter mein koi active partner nahi mila. 'All Karachi' try karein ya search clear karein."
                                        } else {
                                            "Abhi is category mein koi live Karigar register nahi hua. Pull down to refresh ya Partner mode se profile banayein."
                                        },
                                        actionLabel = if (selectedArea != "All Karachi" || searchQuery.isNotBlank()) "Show All Karachi" else null,
                                        onAction = if (selectedArea != "All Karachi" || searchQuery.isNotBlank()) {
                                            {
                                                viewModel.updateAreaFilter("All Karachi")
                                                viewModel.updateSearchQuery("")
                                            }
                                        } else null
                                    )
                                }
                            } else {
                                LazyColumn(
                                    contentPadding = PaddingValues(16.dp),
                                    verticalArrangement = Arrangement.spacedBy(12.dp),
                                    modifier = Modifier.fillMaxSize()
                                ) {
                                    items(state.data, key = { it.id }) { karigar ->
                                        KarigarCard(
                                            karigar = karigar,
                                            onBookNow = { bookingTarget = karigar }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    val target = bookingTarget
    if (target != null) {
        BookingRequestSheet(
            karigar = target,
            userProfile = userProfile,
            isSubmitting = actionInProgress,
            onDismiss = { bookingTarget = null },
            onEditProfile = {
                bookingTarget = null
                onEditProfileShortcut()
            },
            onSubmit = { customerName, customerPhone, customerArea, details ->
                viewModel.createBooking(
                    karigar = target,
                    customerName = customerName,
                    customerPhone = customerPhone,
                    customerArea = customerArea,
                    details = details,
                    onSuccess = { bookingTarget = null }
                )
            }
        )
    }
}

@Composable
private fun KarigarCard(
    karigar: KarigarProfile,
    onBookNow: () -> Unit
) {
    val context = LocalContext.current

    Surface(
        shape = RoundedCornerShape(18.dp),
        color = SlateCard,
        border = BorderStroke(1.dp, SlateBorder),
        tonalElevation = 2.dp,
        modifier = Modifier
            .fillMaxWidth()
            .testTag("karigar_card_${karigar.id}")
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(GoldContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = karigar.fullName.take(1).uppercase(),
                            style = MaterialTheme.typography.titleLarge,
                            color = GoldBright
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = karigar.fullName,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = TextPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                color = EmeraldContainer,
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = karigar.category,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = EmeraldBright,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = karigar.town,
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }

                Surface(
                    color = GoldContainer,
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, GoldAccent.copy(alpha = 0.5f))
                ) {
                    Text(
                        text = karigar.rate,
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                        color = GoldBright,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }

            Surface(
                color = SlateCardElevated,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Rounded.LocationOn,
                        contentDescription = null,
                        tint = GoldAccent,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "${karigar.town} — ${karigar.exactLocation}",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextPrimary
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onBookNow,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = GoldAccent,
                        contentColor = OnGold
                    ),
                    modifier = Modifier
                        .weight(1.25f)
                        .minimumInteractiveComponentSize()
                        .testTag("book_now_button_${karigar.id}")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.BookmarkAdd,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Book Now",
                        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold)
                    )
                }

                OutlinedButton(
                    onClick = { ContactIntents.dialPhoneNumber(context, karigar.phone) },
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, SlateBorder),
                    modifier = Modifier
                        .weight(0.85f)
                        .minimumInteractiveComponentSize()
                        .testTag("call_karigar_button_${karigar.id}")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Call,
                        contentDescription = "Direct Call",
                        tint = EmeraldBright,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Call", color = TextPrimary)
                }

                Button(
                    onClick = {
                        ContactIntents.openWhatsApp(
                            context = context,
                            phone = karigar.phone,
                            message = "Assalam-o-Alaikum ${karigar.fullName}, mujhe ${karigar.category} service (${karigar.town}) chahiye. Karigar app se contact kar raha hoon."
                        )
                    },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = EmeraldContainer,
                        contentColor = EmeraldBright
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .minimumInteractiveComponentSize()
                        .testTag("whatsapp_karigar_button_${karigar.id}")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Rounded.Chat,
                        contentDescription = "WhatsApp",
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("WhatsApp", maxLines = 1)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun BookingRequestSheet(
    karigar: KarigarProfile,
    userProfile: UserProfile,
    isSubmitting: Boolean,
    onDismiss: () -> Unit,
    onEditProfile: () -> Unit,
    onSubmit: (name: String, phone: String, area: String, details: String) -> Unit
) {
    val defaultArea = buildString {
        if (userProfile.town.isNotBlank()) append(userProfile.town)
        if (userProfile.address.isNotBlank()) {
            if (isNotEmpty()) append(" — ")
            append(userProfile.address)
        }
    }

    var customerName by remember(userProfile) { mutableStateOf(userProfile.displayName) }
    var customerPhone by remember(userProfile) { mutableStateOf(userProfile.phone) }
    var customerArea by remember(userProfile) { mutableStateOf(defaultArea) }
    var details by remember { mutableStateOf("") }
    var localError by remember { mutableStateOf<String?>(null) }

    val fieldColors = OutlinedTextFieldDefaults.colors(
        focusedBorderColor = GoldAccent,
        unfocusedBorderColor = SlateBorder,
        focusedContainerColor = SlateCardElevated,
        unfocusedContainerColor = SlateCardElevated,
        focusedTextColor = TextPrimary,
        unfocusedTextColor = TextPrimary,
        focusedLabelColor = GoldBright,
        unfocusedLabelColor = TextSecondary
    )

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = SlateCard
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Book ${karigar.fullName}",
                        style = MaterialTheme.typography.titleLarge,
                        color = TextPrimary
                    )
                    Text(
                        text = "${karigar.category} • ${karigar.rate}",
                        style = MaterialTheme.typography.bodySmall,
                        color = GoldBright
                    )
                }
                TextButton(onClick = onEditProfile) {
                    Text("Edit Saved Profile", color = EmeraldBright)
                }
            }

            OutlinedTextField(
                value = customerName,
                onValueChange = { customerName = it; localError = null },
                label = { Text("Your Name") },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                colors = fieldColors,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("booking_customer_name_input")
            )

            OutlinedTextField(
                value = customerPhone,
                onValueChange = { customerPhone = it; localError = null },
                label = { Text("Your Phone / WhatsApp") },
                placeholder = { Text("0300-1234567", color = TextMuted) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                colors = fieldColors,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("booking_customer_phone_input")
            )

            OutlinedTextField(
                value = customerArea,
                onValueChange = { customerArea = it; localError = null },
                label = { Text("Your Karachi Area / Full Address") },
                placeholder = { Text("e.g. Gulshan-e-Iqbal Block 13-D, Street 4", color = TextMuted) },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                colors = fieldColors,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("booking_customer_area_input")
            )

            OutlinedTextField(
                value = details,
                onValueChange = { details = it },
                label = { Text("Work / Trip Details (Optional)") },
                placeholder = { Text("e.g. AC service chahiye aaj shaam 5 baje", color = TextMuted) },
                minLines = 2,
                maxLines = 4,
                shape = RoundedCornerShape(14.dp),
                colors = fieldColors,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("booking_details_input")
            )

            if (localError != null) {
                Text(
                    text = localError!!,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error
                )
            }

            Button(
                onClick = {
                    when {
                        customerName.trim().length < 2 -> localError = "Please enter your name."
                        customerPhone.trim().length < 7 -> localError = "Please enter a valid Phone / WhatsApp number."
                        customerArea.trim().length < 2 -> localError = "Please enter your Karachi area / address."
                        else -> onSubmit(customerName, customerPhone, customerArea, details)
                    }
                },
                enabled = !isSubmitting,
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = GoldAccent,
                    contentColor = OnGold
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("confirm_booking_button")
            ) {
                Text(
                    text = if (isSubmitting) "Sending Request..." else "Send Booking Request",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
            }
        }
    }
}
