package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Logout
import androidx.compose.material.icons.rounded.Category
import androidx.compose.material.icons.rounded.LocationOn
import androidx.compose.material.icons.rounded.Payments
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Phone
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.model.KarachiConstants
import com.example.model.KarigarProfile
import com.example.model.UserProfile
import com.example.ui.components.KarachiPickerField
import com.example.ui.theme.CrimsonError
import com.example.ui.theme.EmeraldAccent
import com.example.ui.theme.EmeraldBright
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.GoldBright
import com.example.ui.theme.OnEmerald
import com.example.ui.theme.SlateBorder
import com.example.ui.theme.SlateCard
import com.example.ui.theme.SlateCardElevated
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.KarigarViewModel

@Composable
fun KarigarProfileSetupScreen(
    existingProfile: KarigarProfile?,
    userProfile: UserProfile,
    viewModel: KarigarViewModel,
    onSaved: () -> Unit,
    onSwitchRole: () -> Unit,
    onSignOutClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val actionInProgress by viewModel.actionInProgress.collectAsStateWithLifecycle()

    var fullName by remember(existingProfile, userProfile) {
        mutableStateOf(existingProfile?.fullName ?: userProfile.displayName)
    }
    var category by remember(existingProfile, userProfile) {
        mutableStateOf(
            existingProfile?.category
                ?: userProfile.karigarCategory.takeIf { it in KarachiConstants.CATEGORY_NAMES }
                ?: KarachiConstants.CATEGORY_NAMES.first()
        )
    }
    var town by remember(existingProfile, userProfile) {
        mutableStateOf(
            existingProfile?.town
                ?: userProfile.town.takeIf { it in KarachiConstants.KARACHI_TOWNS }
                ?: KarachiConstants.KARACHI_TOWNS.first()
        )
    }
    var exactLocation by remember(existingProfile, userProfile) {
        mutableStateOf(existingProfile?.exactLocation ?: userProfile.address)
    }
    var phone by remember(existingProfile, userProfile) {
        mutableStateOf(existingProfile?.phone ?: userProfile.phone)
    }
    var rate by remember(existingProfile, userProfile) {
        mutableStateOf(existingProfile?.rate ?: userProfile.karigarRate)
    }
    var active by remember(existingProfile, userProfile) {
        mutableStateOf(existingProfile?.active ?: userProfile.karigarActive)
    }
    var validationError by remember { mutableStateOf<String?>(null) }

    val fieldColors = OutlinedTextFieldDefaults.colors(
        focusedBorderColor = EmeraldAccent,
        unfocusedBorderColor = SlateBorder,
        focusedContainerColor = SlateCardElevated,
        unfocusedContainerColor = SlateCardElevated,
        focusedTextColor = TextPrimary,
        unfocusedTextColor = TextPrimary,
        focusedLabelColor = EmeraldBright,
        unfocusedLabelColor = TextSecondary
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .widthIn(max = 600.dp)
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
            .testTag("karigar_profile_setup_screen"),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Card(
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = SlateCard),
            border = BorderStroke(1.dp, EmeraldAccent.copy(alpha = 0.5f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = if (existingProfile == null) "Karigar Profile Setup" else "Edit Karigar Profile",
                    style = MaterialTheme.typography.titleLarge,
                    color = TextPrimary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Apna naam, category, area, exact location, phone aur rate save karein taake Karachi customers aapko book aur contact kar sakein.",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }
        }

        OutlinedTextField(
            value = fullName,
            onValueChange = { fullName = it; validationError = null },
            label = { Text("Poora Naam / Business Name") },
            leadingIcon = { Icon(Icons.Rounded.Person, contentDescription = null, tint = EmeraldAccent) },
            singleLine = true,
            shape = RoundedCornerShape(14.dp),
            colors = fieldColors,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("karigar_fullname_input")
        )

        KarachiPickerField(
            label = "Category (12 Services)",
            selectedValue = category,
            placeholder = "Select category",
            options = KarachiConstants.CATEGORY_NAMES,
            onSelected = { category = it },
            leadingIcon = Icons.Rounded.Category,
            testTag = "karigar_category_picker"
        )

        KarachiPickerField(
            label = "Area / Town (Karachi)",
            selectedValue = town,
            placeholder = "Select Karachi area",
            options = KarachiConstants.KARACHI_TOWNS,
            onSelected = { town = it },
            leadingIcon = Icons.Rounded.LocationOn,
            testTag = "karigar_town_picker"
        )

        OutlinedTextField(
            value = exactLocation,
            onValueChange = { exactLocation = it; validationError = null },
            label = { Text("Exact Location / Gali / Sector") },
            placeholder = { Text("e.g. Block 13-D, Near Hassan Square", color = TextMuted) },
            singleLine = true,
            shape = RoundedCornerShape(14.dp),
            colors = fieldColors,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("karigar_location_input")
        )

        OutlinedTextField(
            value = phone,
            onValueChange = { phone = it; validationError = null },
            label = { Text("Phone / WhatsApp Number") },
            placeholder = { Text("0321-9876543", color = TextMuted) },
            leadingIcon = { Icon(Icons.Rounded.Phone, contentDescription = null, tint = EmeraldAccent) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
            singleLine = true,
            shape = RoundedCornerShape(14.dp),
            colors = fieldColors,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("karigar_phone_input")
        )

        OutlinedTextField(
            value = rate,
            onValueChange = { rate = it; validationError = null },
            label = { Text("Rate per Service (e.g. Rs. 2500/day or per trip)") },
            placeholder = { Text("Rs. 2500/day", color = TextMuted) },
            leadingIcon = { Icon(Icons.Rounded.Payments, contentDescription = null, tint = GoldAccent) },
            singleLine = true,
            shape = RoundedCornerShape(14.dp),
            colors = fieldColors,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("karigar_rate_input")
        )

        Surface(
            shape = RoundedCornerShape(14.dp),
            color = SlateCard,
            border = BorderStroke(1.dp, SlateBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Listing Live Status",
                        style = MaterialTheme.typography.titleSmall,
                        color = TextPrimary
                    )
                    Text(
                        text = if (active) "Visible to all Karachi customers" else "Hidden from customer search",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
                Switch(
                    checked = active,
                    onCheckedChange = { active = it },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = OnEmerald,
                        checkedTrackColor = EmeraldAccent
                    ),
                    modifier = Modifier.testTag("karigar_setup_active_switch")
                )
            }
        }

        if (validationError != null) {
            Text(
                text = validationError!!,
                style = MaterialTheme.typography.bodySmall,
                color = CrimsonError
            )
        }

        Button(
            onClick = {
                when {
                    fullName.trim().length < 2 -> validationError = "Poora naam kam az kam 2 huroof ka likhein."
                    exactLocation.trim().length < 2 -> validationError = "Exact location / gali likhein."
                    phone.trim().length < 7 -> validationError = "Valid phone / WhatsApp number likhein."
                    rate.trim().length < 2 -> validationError = "Apna rate likhein (maslan Rs. 2500/day)."
                    else -> {
                        viewModel.saveKarigarProfile(
                            fullName = fullName,
                            category = category,
                            town = town,
                            exactLocation = exactLocation,
                            phone = phone,
                            rate = rate,
                            active = active,
                            onSaved = onSaved
                        )
                    }
                }
            },
            enabled = !actionInProgress,
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = EmeraldAccent,
                contentColor = OnEmerald
            ),
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp)
                .testTag("save_karigar_profile_button")
        ) {
            Icon(Icons.Rounded.Save, contentDescription = null, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = if (actionInProgress) "Saving..." else if (existingProfile == null) "Save & Publish Profile" else "Update Partner Profile",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
        }

        if (existingProfile == null) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = onSwitchRole,
                    border = BorderStroke(1.dp, GoldAccent),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .minimumInteractiveComponentSize()
                        .testTag("karigar_setup_switch_role_button")
                ) {
                    Icon(Icons.Rounded.SwapHoriz, contentDescription = null, tint = GoldBright, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Switch Role", color = GoldBright)
                }

                OutlinedButton(
                    onClick = onSignOutClick,
                    border = BorderStroke(1.dp, CrimsonError.copy(alpha = 0.7f)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .minimumInteractiveComponentSize()
                        .testTag("karigar_setup_sign_out_button")
                ) {
                    Icon(Icons.AutoMirrored.Rounded.Logout, contentDescription = null, tint = CrimsonError, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Sign Out", color = CrimsonError)
                }
            }
        }
    }
}
