package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val MidnightBackground = Color(0xFF06080F)
val SlateCard = Color(0xFF0F172A)
val SlateCardElevated = Color(0xFF162038)
val SlateSurfaceVariant = Color(0xFF1E293B)
val SlateBorder = Color(0xFF28354E)

val GoldAccent = Color(0xFFF59E0B)
val GoldBright = Color(0xFFFBBF24)
val GoldContainer = Color(0xFF3B2605)
val OnGold = Color(0xFF1A1000)

val EmeraldAccent = Color(0xFF10B981)
val EmeraldBright = Color(0xFF34D399)
val EmeraldContainer = Color(0xFF053325)
val OnEmerald = Color(0xFF002116)

val CrimsonError = Color(0xFFEF4444)
val CrimsonContainer = Color(0xFF3B0D12)
val InfoSky = Color(0xFF38BDF8)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
