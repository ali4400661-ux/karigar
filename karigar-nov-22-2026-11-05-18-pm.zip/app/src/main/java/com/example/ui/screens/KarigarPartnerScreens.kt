package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Chat
import androidx.compose.material.icons.rounded.Call
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Dashboard
import androidx.compose.material.icons.rounded.DoneAll
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Handyman
import androidx.compose.material.icons.rounded.Inbox
import androidx.compose.material.icons.rounded.LocationOn
import androidx.compose.material.icons.rounded.Phone
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.model.BookingRequest
import com.example.model.BookingStatus
import com.example.model.KarigarProfile
import com.example.model.UiState
import com.example.model.UserProfile
import com.example.model.UserRole
import com.example.ui.components.BookingStatusBadge
import com.example.ui.components.EmptyStateView
import com.example.ui.components.ErrorStateView
import com.example.ui.components.KarigarTopBar
import com.example.ui.components.LoadingStateView
import com.example.ui.theme.CrimsonContainer
import com.example.ui.theme.CrimsonError
import com.example.ui.theme.EmeraldAccent
import com.example.ui.theme.EmeraldBright
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.GoldBright
import com.example.ui.theme.GoldContainer
import com.example.ui.theme.MidnightBackground
import com.example.ui.theme.OnEmerald
import com.example.ui.theme.SlateBorder
import com.example.ui.theme.SlateCard
import com.example.ui.theme.SlateCardElevated
import com.example.ui.theme.SlateSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.KarigarViewModel
import com.example.util.ContactIntents

@Composable
fun KarigarShell(
    viewModel: KarigarViewModel,
    userProfile: UserProfile,
    onSwitchRole: () -> Unit,
    onSignOutClick: () -> Unit
) {
    val myKarigarState by viewModel.myKarigarProfileState.collectAsStateWithLifecycle()
    val snackbarMessage by viewModel.snackbarMessage.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(snackbarMessage) {
        val msg = snackbarMessage
        if (msg != null) {
            snackbarHostState.showSnackbar(msg)
            viewModel.clearSnackbar()
        }
    }

    var selectedTab by rememberSaveable { mutableIntStateOf(0) }

    val hasProfile = (myKarigarState as? UiState.Success)?.data != null
    if (selectedTab != 0) {
        BackHandler { selectedTab = 0 }
    }

    val navItems = listOf(
        Triple("Dashboard", Icons.Rounded.Dashboard, "nav_karigar_dashboard"),
        Triple("Partner Profile", Icons.Rounded.Handyman, "nav_karigar_profile")
    )

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useRail = maxWidth >= 600.dp

        Scaffold(
            containerColor = MidnightBackground,
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
            topBar = {
                KarigarTopBar(
                    role = UserRole.KARIGAR,
                    onSwitchRole = onSwitchRole,
                    onSignOutClick = onSignOutClick
                )
            },
            bottomBar = {
                if (!useRail && hasProfile) {
                    NavigationBar(
                        containerColor = SlateCard,
                        tonalElevation = 4.dp
                    ) {
                        navItems.forEachIndexed { index, (label, icon, tag) ->
                            NavigationBarItem(
                                selected = selectedTab == index,
                                onClick = { selectedTab = index },
                                icon = { Icon(imageVector = icon, contentDescription = label) },
                                label = { Text(label, style = MaterialTheme.typography.labelMedium) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = OnEmerald,
                                    selectedTextColor = EmeraldBright,
                                    indicatorColor = EmeraldAccent,
                                    unselectedIconColor = TextSecondary,
                                    unselectedTextColor = TextSecondary
                                ),
                                modifier = Modifier.testTag(tag)
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (useRail && hasProfile) {
                    NavigationRail(
                        containerColor = SlateCard,
                        modifier = Modifier.fillMaxHeight()
                    ) {
                        Spacer(modifier = Modifier.height(16.dp))
                        navItems.forEachIndexed { index, (label, icon, tag) ->
                            NavigationRailItem(
                                selected = selectedTab == index,
                                onClick = { selectedTab = index },
                                icon = { Icon(imageVector = icon, contentDescription = label) },
                                label = { Text(label) },
                                colors = NavigationRailItemDefaults.colors(
                                    selectedIconColor = OnEmerald,
                                    selectedTextColor = EmeraldBright,
                                    indicatorColor = EmeraldAccent,
                                    unselectedIconColor = TextSecondary,
                                    unselectedTextColor = TextSecondary
                                ),
                                modifier = Modifier.testTag(tag)
                            )
                        }
                    }
                }

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxSize(),
                    contentAlignment = Alignment.TopCenter
                ) {
                    when (val state = myKarigarState) {
                        is UiState.Loading -> LoadingStateView("Loading Partner Dashboard...")
                        is UiState.Error -> {
                            Box(modifier = Modifier.padding(16.dp)) {
                                ErrorStateView(message = state.message)
                            }
                        }
                        is UiState.Success -> {
                            val profile = state.data
                            if (profile == null || selectedTab == 1) {
                                KarigarProfileSetupScreen(
                                    existingProfile = profile,
                                    userProfile = userProfile,
                                    viewModel = viewModel,
                                    onSaved = { selectedTab = 0 },
                                    onSwitchRole = onSwitchRole,
                                    onSignOutClick = onSignOutClick
                                )
                            } else {
                                KarigarDashboardScreen(
                                    karigarProfile = profile,
                                    viewModel = viewModel,
                                    onEditProfile = { selectedTab = 1 }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun KarigarDashboardScreen(
    karigarProfile: KarigarProfile,
    viewModel: KarigarViewModel,
    onEditProfile: () -> Unit
) {
    val bookingsState by viewModel.karigarBookingsState.collectAsStateWithLifecycle()
    val isRefreshing by viewModel.isRefreshing.collectAsStateWithLifecycle()

    PullToRefreshBox(
        isRefreshing = isRefreshing,
        onRefresh = { viewModel.refreshBookings(isKarigar = true) },
        modifier = Modifier
            .fillMaxSize()
            .widthIn(max = 720.dp)
    ) {
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            // Live Profile Status Card
            item {
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = SlateCard,
                    border = BorderStroke(
                        1.2.dp,
                        if (karigarProfile.active) EmeraldAccent.copy(alpha = 0.7f) else SlateBorder
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(48.dp)
                                        .clip(CircleShape)
                                        .background(if (karigarProfile.active) EmeraldContainer else SlateSurfaceVariant),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.Handyman,
                                        contentDescription = null,
                                        tint = if (karigarProfile.active) EmeraldAccent else TextMuted,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = karigarProfile.fullName,
                                        style = MaterialTheme.typography.titleLarge,
                                        color = TextPrimary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "${karigarProfile.category} • ${karigarProfile.town}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = EmeraldBright
                                    )
                                }
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Switch(
                                    checked = karigarProfile.active,
                                    onCheckedChange = { viewModel.toggleKarigarActive(it) },
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = OnEmerald,
                                        checkedTrackColor = EmeraldAccent,
                                        uncheckedThumbColor = TextSecondary,
                                        uncheckedTrackColor = SlateSurfaceVariant
                                    ),
                                    modifier = Modifier.testTag("karigar_active_switch")
                                )
                                Text(
                                    text = if (karigarProfile.active) "LIVE" else "PAUSED",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (karigarProfile.active) EmeraldBright else TextMuted
                                )
                            }
                        }

                        Surface(
                            color = SlateCardElevated,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "Rate: ${karigarProfile.rate}",
                                        style = MaterialTheme.typography.labelLarge,
                                        color = GoldBright
                                    )
                                    Text(
                                        text = karigarProfile.phone,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = TextSecondary
                                    )
                                }
                                Text(
                                    text = "Location: ${karigarProfile.exactLocation}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextPrimary
                                )
                            }
                        }

                        OutlinedButton(
                            onClick = onEditProfile,
                            border = BorderStroke(1.dp, GoldAccent.copy(alpha = 0.7f)),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .minimumInteractiveComponentSize()
                                .testTag("edit_karigar_profile_button")
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Edit,
                                contentDescription = null,
                                tint = GoldBright,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Edit Partner Profile",
                                style = MaterialTheme.typography.labelLarge,
                                color = GoldBright
                            )
                        }
                    }
                }
            }

            // Booking Requests Section
            when (val state = bookingsState) {
                is UiState.Loading -> {
                    item { LoadingStateView("Loading incoming requests...") }
                }
                is UiState.Error -> {
                    item {
                        ErrorStateView(
                            message = state.message,
                            onRetry = { viewModel.refreshBookings(isKarigar = true) }
                        )
                    }
                }
                is UiState.Success -> {
                    val pendingCount = state.data.count { it.parsedStatus == BookingStatus.PENDING }
                    val acceptedCount = state.data.count { it.parsedStatus == BookingStatus.ACCEPTED }
                    val completedCount = state.data.count { it.parsedStatus == BookingStatus.COMPLETED }

                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            DashboardMetricChip(
                                label = "Pending",
                                count = pendingCount,
                                color = GoldBright,
                                bg = GoldContainer,
                                modifier = Modifier.weight(1f)
                            )
                            DashboardMetricChip(
                                label = "Accepted",
                                count = acceptedCount,
                                color = Color(0xFF38BDF8),
                                bg = Color(0xFF0A2A43),
                                modifier = Modifier.weight(1f)
                            )
                            DashboardMetricChip(
                                label = "Completed",
                                count = completedCount,
                                color = EmeraldBright,
                                bg = EmeraldContainer,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    item {
                        Text(
                            text = "Booking Requests (${state.data.size})",
                            style = MaterialTheme.typography.headlineSmall,
                            color = TextPrimary,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }

                    if (state.data.isEmpty()) {
                        item {
                            EmptyStateView(
                                icon = Icons.Rounded.Inbox,
                                title = "No Booking Requests Yet",
                                subtitle = if (karigarProfile.active) {
                                    "Aapka profile Karachi customers ke liye live hai. Jab koi book karega to yahan foran nazar aayega."
                                } else {
                                    "Aapka profile abhi PAUSED hai. Customers ko dikhne ke liye upar se LIVE switch on karein."
                                }
                            )
                        }
                    } else {
                        items(state.data, key = { it.id }) { booking ->
                            IncomingBookingCard(
                                booking = booking,
                                onUpdateStatus = { newStatus ->
                                    viewModel.updateBookingStatus(booking.id, newStatus)
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DashboardMetricChip(
    label: String,
    count: Int,
    color: Color,
    bg: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = bg.copy(alpha = 0.7f),
        border = BorderStroke(1.dp, color.copy(alpha = 0.35f)),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(vertical = 12.dp, horizontal = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = count.toString(),
                style = MaterialTheme.typography.headlineSmall,
                color = color
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = TextPrimary
            )
        }
    }
}

@Composable
private fun IncomingBookingCard(
    booking: BookingRequest,
    onUpdateStatus: (BookingStatus) -> Unit
) {
    val context = LocalContext.current
    val status = booking.parsedStatus

    Surface(
        shape = RoundedCornerShape(18.dp),
        color = SlateCard,
        border = BorderStroke(1.dp, SlateBorder),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("karigar_booking_card_${booking.id}")
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = booking.customerName,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = TextPrimary
                    )
                    Text(
                        text = ContactIntents.formatTimestamp(booking.createdAt),
                        style = MaterialTheme.typography.bodySmall,
                        color = TextMuted
                    )
                }
                BookingStatusBadge(status = status)
            }

            Surface(
                color = SlateCardElevated,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Rounded.LocationOn,
                            contentDescription = null,
                            tint = GoldAccent,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = booking.customerArea,
                            style = MaterialTheme.typography.bodySmall,
                            color = TextPrimary
                        )
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Rounded.Phone,
                            contentDescription = null,
                            tint = EmeraldBright,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = booking.customerPhone,
                            style = MaterialTheme.typography.bodySmall,
                            color = EmeraldBright
                        )
                    }
                    if (booking.details.isNotBlank()) {
                        Text(
                            text = "Details: ${booking.details}",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }
                }
            }

            // Direct contact row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = { ContactIntents.dialPhoneNumber(context, booking.customerPhone) },
                    border = BorderStroke(1.dp, SlateBorder),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .minimumInteractiveComponentSize()
                        .testTag("karigar_call_customer_${booking.id}")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Call,
                        contentDescription = "Call Customer",
                        tint = EmeraldBright,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Call", color = TextPrimary)
                }

                OutlinedButton(
                    onClick = {
                        ContactIntents.openWhatsApp(
                            context,
                            booking.customerPhone,
                            "Assalam-o-Alaikum ${booking.customerName}, main ${booking.karigarName} (${booking.karigarCategory}) Karigar app se aapki booking ke silsilay mein rabta kar raha hoon."
                        )
                    },
                    border = BorderStroke(1.dp, EmeraldAccent.copy(alpha = 0.6f)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .minimumInteractiveComponentSize()
                        .testTag("karigar_whatsapp_customer_${booking.id}")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Rounded.Chat,
                        contentDescription = "WhatsApp Customer",
                        tint = EmeraldBright,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("WhatsApp", color = EmeraldBright)
                }
            }

            // Status Action Buttons
            if (status == BookingStatus.PENDING) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { onUpdateStatus(BookingStatus.ACCEPTED) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = EmeraldAccent,
                            contentColor = OnEmerald
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .minimumInteractiveComponentSize()
                            .testTag("accept_booking_button_${booking.id}")
                    ) {
                        Icon(Icons.Rounded.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Accept", fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = { onUpdateStatus(BookingStatus.COMPLETED) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = GoldContainer,
                            contentColor = GoldBright
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .minimumInteractiveComponentSize()
                            .testTag("complete_booking_button_${booking.id}")
                    ) {
                        Icon(Icons.Rounded.DoneAll, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Complete")
                    }

                    Button(
                        onClick = { onUpdateStatus(BookingStatus.DECLINED) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = CrimsonContainer,
                            contentColor = Color(0xFFFCA5A5)
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .minimumInteractiveComponentSize()
                            .testTag("decline_booking_button_${booking.id}")
                    ) {
                        Icon(Icons.Rounded.Close, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Decline")
                    }
                }
            } else if (status == BookingStatus.ACCEPTED) {
                Button(
                    onClick = { onUpdateStatus(BookingStatus.COMPLETED) },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = EmeraldAccent,
                        contentColor = OnEmerald
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .minimumInteractiveComponentSize()
                        .testTag("mark_complete_booking_button_${booking.id}")
                ) {
                    Icon(Icons.Rounded.DoneAll, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Mark Job as Completed", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
