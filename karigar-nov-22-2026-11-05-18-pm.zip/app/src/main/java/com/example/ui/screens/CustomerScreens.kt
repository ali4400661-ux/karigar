package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Chat
import androidx.compose.material.icons.automirrored.rounded.Logout
import androidx.compose.material.icons.rounded.BookmarkAdded
import androidx.compose.material.icons.rounded.Bookmarks
import androidx.compose.material.icons.rounded.Call
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.HomeRepairService
import androidx.compose.material.icons.rounded.LocationOn
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Phone
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.model.BookingRequest
import com.example.model.BookingStatus
import com.example.model.KarachiConstants
import com.example.model.UiState
import com.example.model.UserProfile
import com.example.model.UserRole
import com.example.ui.components.BookingStatusBadge
import com.example.ui.components.EmptyStateView
import com.example.ui.components.ErrorStateView
import com.example.ui.components.KarachiPickerField
import com.example.ui.components.KarigarTopBar
import com.example.ui.components.LoadingStateView
import com.example.ui.theme.CrimsonError
import com.example.ui.theme.EmeraldAccent
import com.example.ui.theme.EmeraldBright
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.GoldBright
import com.example.ui.theme.GoldContainer
import com.example.ui.theme.MidnightBackground
import com.example.ui.theme.OnGold
import com.example.ui.theme.SlateBorder
import com.example.ui.theme.SlateCard
import com.example.ui.theme.SlateCardElevated
import com.example.ui.theme.SlateSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.KarigarViewModel
import com.example.util.ContactIntents

@Composable
fun CustomerShell(
    viewModel: KarigarViewModel,
    userProfile: UserProfile,
    onSwitchRole: () -> Unit,
    onSignOutClick: () -> Unit
) {
    var selectedTab by rememberSaveable { mutableIntStateOf(0) }
    val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()
    val snackbarMessage by viewModel.snackbarMessage.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(snackbarMessage) {
        val msg = snackbarMessage
        if (msg != null) {
            snackbarHostState.showSnackbar(msg)
            viewModel.clearSnackbar()
        }
    }

    if (selectedCategory != null) {
        KarigarListScreen(
            categoryName = selectedCategory!!,
            viewModel = viewModel,
            userProfile = userProfile,
            snackbarHostState = snackbarHostState,
            onBack = { viewModel.selectCategory(null) },
            onEditProfileShortcut = {
                viewModel.selectCategory(null)
                selectedTab = 2
            }
        )
        return
    }

    if (selectedTab != 0) {
        BackHandler { selectedTab = 0 }
    }

    val navItems = listOf(
        Triple("Services", Icons.Rounded.HomeRepairService, "nav_customer_services"),
        Triple("My Bookings", Icons.Rounded.Bookmarks, "nav_customer_bookings"),
        Triple("Profile", Icons.Rounded.Person, "nav_customer_profile")
    )

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useRail = maxWidth >= 600.dp

        Scaffold(
            containerColor = MidnightBackground,
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
            topBar = {
                KarigarTopBar(
                    role = UserRole.CUSTOMER,
                    onSwitchRole = onSwitchRole,
                    onSignOutClick = onSignOutClick
                )
            },
            bottomBar = {
                if (!useRail) {
                    NavigationBar(
                        containerColor = SlateCard,
                        tonalElevation = 4.dp
                    ) {
                        navItems.forEachIndexed { index, (label, icon, tag) ->
                            NavigationBarItem(
                                selected = selectedTab == index,
                                onClick = { selectedTab = index },
                                icon = {
                                    Icon(imageVector = icon, contentDescription = label)
                                },
                                label = {
                                    Text(text = label, style = MaterialTheme.typography.labelMedium)
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = OnGold,
                                    selectedTextColor = GoldBright,
                                    indicatorColor = GoldAccent,
                                    unselectedIconColor = TextSecondary,
                                    unselectedTextColor = TextSecondary
                                ),
                                modifier = Modifier.testTag(tag)
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (useRail) {
                    NavigationRail(
                        containerColor = SlateCard,
                        modifier = Modifier.fillMaxHeight()
                    ) {
                        Spacer(modifier = Modifier.height(16.dp))
                        navItems.forEachIndexed { index, (label, icon, tag) ->
                            NavigationRailItem(
                                selected = selectedTab == index,
                                onClick = { selectedTab = index },
                                icon = { Icon(imageVector = icon, contentDescription = label) },
                                label = { Text(label) },
                                colors = NavigationRailItemDefaults.colors(
                                    selectedIconColor = OnGold,
                                    selectedTextColor = GoldBright,
                                    indicatorColor = GoldAccent,
                                    unselectedIconColor = TextSecondary,
                                    unselectedTextColor = TextSecondary
                                ),
                                modifier = Modifier.testTag(tag)
                            )
                        }
                    }
                }

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxSize(),
                    contentAlignment = Alignment.TopCenter
                ) {
                    when (selectedTab) {
                        0 -> CustomerDashboardScreen(
                            userProfile = userProfile,
                            onCategoryClick = { category -> viewModel.selectCategory(category.name) },
                            onCompleteProfileClick = { selectedTab = 2 }
                        )
                        1 -> CustomerBookingsScreen(
                            viewModel = viewModel,
                            onBrowseServices = { selectedTab = 0 }
                        )
                        2 -> CustomerProfileScreen(
                            userProfile = userProfile,
                            viewModel = viewModel,
                            onSwitchRole = onSwitchRole,
                            onSignOutClick = onSignOutClick
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CustomerBookingsScreen(
    viewModel: KarigarViewModel,
    onBrowseServices: () -> Unit
) {
    val bookingsState by viewModel.customerBookingsState.collectAsStateWithLifecycle()
    val isRefreshing by viewModel.isRefreshing.collectAsStateWithLifecycle()

    PullToRefreshBox(
        isRefreshing = isRefreshing,
        onRefresh = { viewModel.refreshBookings(isKarigar = false) },
        modifier = Modifier
            .fillMaxSize()
            .widthIn(max = 720.dp)
    ) {
        when (val state = bookingsState) {
            is UiState.Loading -> LoadingStateView("Loading your bookings...")
            is UiState.Error -> {
                Box(modifier = Modifier.padding(16.dp)) {
                    ErrorStateView(
                        message = state.message,
                        onRetry = { viewModel.refreshBookings(isKarigar = false) }
                    )
                }
            }
            is UiState.Success -> {
                if (state.data.isEmpty()) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(16.dp),
                        verticalArrangement = Arrangement.Center
                    ) {
                        EmptyStateView(
                            icon = Icons.Rounded.BookmarkAdded,
                            title = "No Booking Requests Yet",
                            subtitle = "Kisi bhi service category se Karigar ya Transport select karein aur Book Now dabayein.",
                            actionLabel = "Browse Services",
                            onAction = onBrowseServices
                        )
                    }
                } else {
                    LazyColumn(
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        item {
                            Text(
                                text = "My Bookings (${state.data.size})",
                                style = MaterialTheme.typography.headlineSmall,
                                color = TextPrimary,
                                modifier = Modifier.padding(bottom = 4.dp)
                            )
                        }
                        items(state.data, key = { it.id }) { booking ->
                            CustomerBookingCard(
                                booking = booking,
                                onCancel = {
                                    viewModel.updateBookingStatus(booking.id, BookingStatus.CANCELLED)
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CustomerBookingCard(
    booking: BookingRequest,
    onCancel: () -> Unit
) {
    val context = LocalContext.current
    val status = booking.parsedStatus

    Surface(
        shape = RoundedCornerShape(18.dp),
        color = SlateCard,
        border = BorderStroke(1.dp, SlateBorder),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("customer_booking_card_${booking.id}")
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = booking.karigarName,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = TextPrimary
                    )
                    Text(
                        text = "${booking.karigarCategory} • ${booking.karigarTown}",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
                BookingStatusBadge(status = status)
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = booking.karigarRate,
                    style = MaterialTheme.typography.labelLarge,
                    color = GoldBright
                )
                Text(
                    text = ContactIntents.formatTimestamp(booking.createdAt),
                    style = MaterialTheme.typography.bodySmall,
                    color = TextMuted
                )
            }

            Surface(
                color = SlateCardElevated,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = "Your Area: ${booking.customerArea}",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextPrimary
                    )
                    if (booking.details.isNotBlank()) {
                        Text(
                            text = "Note: ${booking.details}",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = { ContactIntents.dialPhoneNumber(context, booking.karigarPhone) },
                    border = BorderStroke(1.dp, SlateBorder),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .minimumInteractiveComponentSize()
                        .testTag("booking_call_button_${booking.id}")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Call,
                        contentDescription = "Call Karigar",
                        tint = EmeraldBright,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Call", color = TextPrimary)
                }

                Button(
                    onClick = {
                        ContactIntents.openWhatsApp(
                            context,
                            booking.karigarPhone,
                            "Assalam-o-Alaikum ${booking.karigarName}, maine Karigar app par ${booking.karigarCategory} ke liye booking request bheji hai."
                        )
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = EmeraldContainer,
                        contentColor = EmeraldBright
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .minimumInteractiveComponentSize()
                        .testTag("booking_whatsapp_button_${booking.id}")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Rounded.Chat,
                        contentDescription = "WhatsApp Karigar",
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("WhatsApp")
                }

                if (status == BookingStatus.PENDING) {
                    TextButton(
                        onClick = onCancel,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("booking_cancel_button_${booking.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Close,
                            contentDescription = "Cancel Request",
                            tint = CrimsonError,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun CustomerProfileScreen(
    userProfile: UserProfile,
    viewModel: KarigarViewModel,
    onSwitchRole: () -> Unit,
    onSignOutClick: () -> Unit
) {
    val actionInProgress by viewModel.actionInProgress.collectAsStateWithLifecycle()

    var name by remember(userProfile.userId, userProfile.displayName) {
        mutableStateOf(userProfile.displayName)
    }
    var phone by remember(userProfile.userId, userProfile.phone) {
        mutableStateOf(userProfile.phone)
    }
    var town by remember(userProfile.userId, userProfile.town) {
        mutableStateOf(userProfile.town.ifBlank { KarachiConstants.KARACHI_TOWNS.first() })
    }
    var address by remember(userProfile.userId, userProfile.address) {
        mutableStateOf(userProfile.address)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .widthIn(max = 600.dp)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = SlateCard,
            border = BorderStroke(1.dp, SlateBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(52.dp)
                        .clip(CircleShape)
                        .background(GoldContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Person,
                        contentDescription = null,
                        tint = GoldAccent,
                        modifier = Modifier.size(28.dp)
                    )
                }
                Spacer(modifier = Modifier.width(14.dp))
                Column {
                    Text(
                        text = "Customer Profile",
                        style = MaterialTheme.typography.titleLarge,
                        color = TextPrimary
                    )
                    Text(
                        text = userProfile.email.ifBlank { "Google Account Connected" },
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
            }
        }

        val fieldColors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = GoldAccent,
            unfocusedBorderColor = SlateBorder,
            focusedContainerColor = SlateCardElevated,
            unfocusedContainerColor = SlateCardElevated,
            focusedTextColor = TextPrimary,
            unfocusedTextColor = TextPrimary,
            focusedLabelColor = GoldBright,
            unfocusedLabelColor = TextSecondary
        )

        OutlinedTextField(
            value = name,
            onValueChange = { name = it },
            label = { Text("Full Name (Auto-filled from Google)") },
            singleLine = true,
            shape = RoundedCornerShape(14.dp),
            colors = fieldColors,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("customer_name_input")
        )

        OutlinedTextField(
            value = phone,
            onValueChange = { phone = it },
            label = { Text("Phone / WhatsApp Number") },
            placeholder = { Text("0300-1234567", color = TextMuted) },
            leadingIcon = {
                Icon(Icons.Rounded.Phone, contentDescription = null, tint = GoldAccent)
            },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
            singleLine = true,
            shape = RoundedCornerShape(14.dp),
            colors = fieldColors,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("customer_phone_input")
        )

        KarachiPickerField(
            label = "Karachi Town / Area",
            selectedValue = town,
            placeholder = "Select your Karachi town",
            options = KarachiConstants.KARACHI_TOWNS,
            onSelected = { town = it },
            leadingIcon = Icons.Rounded.LocationOn,
            testTag = "customer_town_picker"
        )

        OutlinedTextField(
            value = address,
            onValueChange = { address = it },
            label = { Text("House / Street / Block / Gali Address") },
            placeholder = { Text("e.g. House 14, Block 13-D, Near Hassan Square", color = TextMuted) },
            minLines = 2,
            maxLines = 3,
            shape = RoundedCornerShape(14.dp),
            colors = fieldColors,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("customer_address_input")
        )

        Button(
            onClick = {
                viewModel.saveCustomerProfile(
                    displayName = name,
                    phone = phone,
                    town = town,
                    address = address
                )
            },
            enabled = !actionInProgress,
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = GoldAccent,
                contentColor = OnGold
            ),
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp)
                .testTag("save_customer_profile_button")
        ) {
            Icon(Icons.Rounded.Save, contentDescription = null, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = if (actionInProgress) "Saving..." else "Save Customer Profile",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
        }

        Surface(
            shape = RoundedCornerShape(18.dp),
            color = SlateCard,
            border = BorderStroke(1.dp, SlateBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Account & Role",
                    style = MaterialTheme.typography.titleSmall,
                    color = TextSecondary
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onSwitchRole,
                        border = BorderStroke(1.dp, EmeraldAccent),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .minimumInteractiveComponentSize()
                            .testTag("profile_switch_role_button")
                    ) {
                        Icon(
                            Icons.Rounded.SwapHoriz,
                            contentDescription = null,
                            tint = EmeraldBright,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Switch Role", color = EmeraldBright)
                    }

                    OutlinedButton(
                        onClick = onSignOutClick,
                        border = BorderStroke(1.dp, CrimsonError.copy(alpha = 0.7f)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .minimumInteractiveComponentSize()
                            .testTag("profile_sign_out_button")
                    ) {
                        Icon(
                            Icons.AutoMirrored.Rounded.Logout,
                            contentDescription = null,
                            tint = CrimsonError,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Sign Out", color = CrimsonError)
                    }
                }
            }
        }
    }
}
