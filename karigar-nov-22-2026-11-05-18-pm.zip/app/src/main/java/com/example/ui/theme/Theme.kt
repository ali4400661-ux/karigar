package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val KarigarDarkColorScheme = darkColorScheme(
    primary = GoldAccent,
    onPrimary = OnGold,
    primaryContainer = GoldContainer,
    onPrimaryContainer = GoldBright,
    secondary = EmeraldAccent,
    onSecondary = OnEmerald,
    secondaryContainer = EmeraldContainer,
    onSecondaryContainer = EmeraldBright,
    tertiary = InfoSky,
    background = MidnightBackground,
    onBackground = TextPrimary,
    surface = SlateCard,
    onSurface = TextPrimary,
    surfaceVariant = SlateSurfaceVariant,
    onSurfaceVariant = TextSecondary,
    surfaceContainer = SlateCard,
    surfaceContainerHigh = SlateCardElevated,
    outline = SlateBorder,
    outlineVariant = SlateSurfaceVariant,
    error = CrimsonError,
    errorContainer = CrimsonContainer,
    onErrorContainer = TextPrimary
)

val KarigarShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun KarigarTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = KarigarDarkColorScheme,
        typography = KarigarTypography,
        shapes = KarigarShapes,
        content = content
    )
}
