package com.example.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.KarigarRepository
import com.example.model.BookingRequest
import com.example.model.BookingStatus
import com.example.model.KarachiConstants
import com.example.model.KarigarProfile
import com.example.model.UiState
import com.example.model.UserProfile
import com.example.model.UserRole
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

@OptIn(ExperimentalCoroutinesApi::class)
class KarigarViewModel(
    private val repository: KarigarRepository,
    private val currentUserId: String,
    initialDisplayName: String,
    initialEmail: String?
) : ViewModel() {

    private val _selectedCategory = MutableStateFlow<String?>(null)
    val selectedCategory: StateFlow<String?> = _selectedCategory.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedAreaFilter = MutableStateFlow(KarachiConstants.AREA_FILTERS.first())
    val selectedAreaFilter: StateFlow<String> = _selectedAreaFilter.asStateFlow()

    private val _isRefreshing = MutableStateFlow(false)
    val isRefreshing: StateFlow<Boolean> = _isRefreshing.asStateFlow()

    private val _actionInProgress = MutableStateFlow(false)
    val actionInProgress: StateFlow<Boolean> = _actionInProgress.asStateFlow()

    private val _snackbarMessage = MutableStateFlow<String?>(null)
    val snackbarMessage: StateFlow<String?> = _snackbarMessage.asStateFlow()

    init {
        viewModelScope.launch {
            repository.ensureUserProfile(currentUserId, initialDisplayName, initialEmail)
                .onFailure { err ->
                    _snackbarMessage.value = err.localizedMessage ?: "Failed to sync account profile."
                }
        }
    }

    private fun <T> Flow<T>.toUiState(tagLabel: String): StateFlow<UiState<T>> =
        this.map<T, UiState<T>> { UiState.Success(it) }
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                val rootError = firestoreError ?: error
                Log.w(TAG, "Error observing $tagLabel", rootError)
                emit(UiState.Error(rootError.localizedMessage ?: "Failed to load $tagLabel"))
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
                initialValue = UiState.Loading
            )

    val userProfileState: StateFlow<UiState<UserProfile?>> =
        repository.observeUserProfile(currentUserId).toUiState("user profile")

    val myKarigarProfileState: StateFlow<UiState<KarigarProfile?>> =
        repository.observeMyKarigarProfile(currentUserId).toUiState("partner profile")

    val customerBookingsState: StateFlow<UiState<List<BookingRequest>>> =
        repository.observeCustomerBookings(currentUserId).toUiState("my bookings")

    val karigarBookingsState: StateFlow<UiState<List<BookingRequest>>> =
        repository.observeKarigarBookings(currentUserId).toUiState("incoming requests")

    private val rawCategoryKarigarsState: StateFlow<UiState<List<KarigarProfile>>> =
        _selectedCategory
            .flatMapLatest { category ->
                if (category.isNullOrBlank()) {
                    flowOf(UiState.Success(emptyList()))
                } else {
                    repository.observeActiveKarigars(currentUserId, category)
                        .map<List<KarigarProfile>, UiState<List<KarigarProfile>>> { UiState.Success(it) }
                        .catch { error ->
                            val firestoreError = generateSequence(error) { it.cause }
                                .filterIsInstance<FirebaseFirestoreException>()
                                .firstOrNull()
                            if (firestoreError == null && error is CancellationException) throw error
                            val rootError = firestoreError ?: error
                            Log.w(TAG, "Error observing karigars for $category", rootError)
                            emit(UiState.Error(rootError.localizedMessage ?: "Failed to load Karigars"))
                        }
                }
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
                initialValue = UiState.Loading
            )

    val filteredKarigarsState: StateFlow<UiState<List<KarigarProfile>>> =
        combine(
            rawCategoryKarigarsState,
            _searchQuery,
            _selectedAreaFilter
        ) { state, query, area ->
            when (state) {
                is UiState.Loading -> UiState.Loading
                is UiState.Error -> state
                is UiState.Success -> {
                    val trimmedQuery = query.trim().lowercase()
                    val filtered = state.data.filter { item ->
                        val matchesArea = area == "All Karachi" || item.town.equals(area, ignoreCase = true)
                        val matchesQuery = trimmedQuery.isEmpty() ||
                            item.fullName.lowercase().contains(trimmedQuery) ||
                            item.exactLocation.lowercase().contains(trimmedQuery) ||
                            item.town.lowercase().contains(trimmedQuery)
                        matchesArea && matchesQuery
                    }
                    UiState.Success(filtered)
                }
            }
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = UiState.Loading
        )

    fun selectCategory(category: String?) {
        _selectedCategory.value = category
        _searchQuery.value = ""
        _selectedAreaFilter.value = KarachiConstants.AREA_FILTERS.first()
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun updateAreaFilter(area: String) {
        _selectedAreaFilter.value = area
    }

    fun clearSnackbar() {
        _snackbarMessage.value = null
    }

    fun selectRole(role: UserRole, onSuccess: () -> Unit = {}) {
        if (_actionInProgress.value) return
        viewModelScope.launch {
            _actionInProgress.value = true
            repository.updateUserRole(currentUserId, role)
                .onSuccess { onSuccess() }
                .onFailure { e ->
                    _snackbarMessage.value = e.localizedMessage ?: "Could not switch role."
                }
            _actionInProgress.value = false
        }
    }

    fun saveCustomerProfile(
        displayName: String,
        phone: String,
        town: String,
        address: String,
        onSaved: () -> Unit = {}
    ) {
        if (_actionInProgress.value) return
        viewModelScope.launch {
            _actionInProgress.value = true
            repository.saveCustomerProfile(currentUserId, displayName, phone, town, address)
                .onSuccess {
                    _snackbarMessage.value = "Customer profile saved!"
                    onSaved()
                }
                .onFailure { e ->
                    _snackbarMessage.value = e.localizedMessage ?: "Failed to save profile."
                }
            _actionInProgress.value = false
        }
    }

    fun saveKarigarProfile(
        fullName: String,
        category: String,
        town: String,
        exactLocation: String,
        phone: String,
        rate: String,
        active: Boolean,
        onSaved: () -> Unit = {}
    ) {
        if (_actionInProgress.value) return
        viewModelScope.launch {
            _actionInProgress.value = true
            repository.saveKarigarProfile(
                userId = currentUserId,
                fullName = fullName,
                category = category,
                town = town,
                exactLocation = exactLocation,
                phone = phone,
                rate = rate,
                active = active
            )
                .onSuccess {
                    _snackbarMessage.value = "Partner profile updated!"
                    onSaved()
                }
                .onFailure { e ->
                    _snackbarMessage.value = e.localizedMessage ?: "Failed to save partner profile."
                }
            _actionInProgress.value = false
        }
    }

    fun toggleKarigarActive(active: Boolean) {
        viewModelScope.launch {
            repository.toggleKarigarActive(currentUserId, active)
                .onSuccess {
                    _snackbarMessage.value = if (active) "Your profile is now Live" else "Your profile is Paused"
                }
                .onFailure { e ->
                    _snackbarMessage.value = e.localizedMessage ?: "Could not update status."
                }
        }
    }

    fun createBooking(
        karigar: KarigarProfile,
        customerName: String,
        customerPhone: String,
        customerArea: String,
        details: String,
        onSuccess: () -> Unit
    ) {
        if (_actionInProgress.value) return
        viewModelScope.launch {
            _actionInProgress.value = true
            repository.createBooking(
                userId = currentUserId,
                karigar = karigar,
                customerName = customerName,
                customerPhone = customerPhone,
                customerArea = customerArea,
                details = details
            )
                .onSuccess {
                    _snackbarMessage.value = "Booking request sent to ${karigar.fullName}!"
                    onSuccess()
                }
                .onFailure { e ->
                    _snackbarMessage.value = e.localizedMessage ?: "Could not send booking request."
                }
            _actionInProgress.value = false
        }
    }

    fun updateBookingStatus(bookingId: String, newStatus: BookingStatus) {
        viewModelScope.launch {
            repository.updateBookingStatus(currentUserId, bookingId, newStatus)
                .onSuccess {
                    _snackbarMessage.value = "Booking marked as ${newStatus.label}"
                }
                .onFailure { e ->
                    _snackbarMessage.value = e.localizedMessage ?: "Failed to update booking."
                }
        }
    }

    fun refreshKarigars() {
        val cat = _selectedCategory.value ?: return
        viewModelScope.launch {
            _isRefreshing.value = true
            repository.refreshActiveKarigars(currentUserId, cat)
                .onFailure { e ->
                    _snackbarMessage.value = e.localizedMessage ?: "Refresh failed."
                }
            _isRefreshing.value = false
        }
    }

    fun refreshBookings(isKarigar: Boolean) {
        viewModelScope.launch {
            _isRefreshing.value = true
            repository.refreshBookingsForRole(currentUserId, isKarigar)
                .onFailure { e ->
                    _snackbarMessage.value = e.localizedMessage ?: "Refresh failed."
                }
            _isRefreshing.value = false
        }
    }

    private companion object {
        const val TAG = "KarigarVM"
        const val STOP_TIMEOUT_MILLIS = 5000L
    }
}
