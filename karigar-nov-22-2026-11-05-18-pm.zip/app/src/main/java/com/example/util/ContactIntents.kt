package com.example.util

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import com.google.firebase.Timestamp
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Locale

object ContactIntents {
    fun dialPhoneNumber(context: Context, phone: String) {
        val cleaned = phone.trim().replace(" ", "").replace("-", "")
        if (cleaned.isBlank()) {
            Toast.makeText(context, "Phone number not available", Toast.LENGTH_SHORT).show()
            return
        }
        val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$cleaned")).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            context.startActivity(intent)
        } catch (_: ActivityNotFoundException) {
            Toast.makeText(context, "No phone dialer app found", Toast.LENGTH_SHORT).show()
        }
    }

    fun openWhatsApp(context: Context, phone: String, message: String) {
        val waNumber = formatPakistanWhatsAppNumber(phone)
        if (waNumber.isBlank()) {
            Toast.makeText(context, "Invalid WhatsApp number", Toast.LENGTH_SHORT).show()
            return
        }
        val encodedMsg = try {
            URLEncoder.encode(message, "UTF-8")
        } catch (_: Exception) {
            ""
        }
        val url = "https://wa.me/$waNumber?text=$encodedMsg"
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            context.startActivity(intent)
        } catch (_: ActivityNotFoundException) {
            Toast.makeText(context, "WhatsApp or browser not available", Toast.LENGTH_SHORT).show()
        }
    }

    private fun formatPakistanWhatsAppNumber(raw: String): String {
        val digits = raw.filter { it.isDigit() }
        if (digits.isBlank()) return ""
        return when {
            digits.startsWith("0092") -> digits.removePrefix("00")
            digits.startsWith("92") -> digits
            digits.startsWith("03") && digits.length >= 10 -> "92" + digits.drop(1)
            digits.startsWith("3") && digits.length == 10 -> "92$digits"
            else -> digits
        }
    }

    fun formatTimestamp(timestamp: Timestamp?): String {
        val ts = timestamp ?: return "Just now"
        val formatter = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault())
        return formatter.format(ts.toDate())
    }
}
