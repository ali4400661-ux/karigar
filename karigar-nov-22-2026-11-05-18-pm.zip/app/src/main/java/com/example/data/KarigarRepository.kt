package com.example.data

import android.content.Context
import com.example.R
import com.example.model.BookingRequest
import com.example.model.BookingStatus
import com.example.model.KarachiConstants
import com.example.model.KarigarProfile
import com.example.model.UserProfile
import com.example.model.UserRole
import com.google.firebase.Firebase
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.Source
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class KarigarRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private fun requireUserId(expectedUid: String? = null): String {
        val uid = auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")
        if (expectedUid != null) {
            check(uid == expectedUid) { "Signed-in user changed; refusing cross-user operation." }
        }
        return uid
    }

    private fun unwrapAndLogStreamError(
        error: Throwable,
        operationType: OperationType,
        path: String,
        expectedUid: String
    ): Nothing {
        val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) throw error
        val exceptionToLog = firestoreError ?: (error as? Exception)
        if (exceptionToLog != null && auth.currentUser?.uid == expectedUid) {
            handleFirestoreError(exceptionToLog, operationType, path)
        }
        throw error
    }

    fun observeUserProfile(userId: String): Flow<UserProfile?> = flow {
        val uid = requireUserId(userId)
        val path = "users/$uid"
        emitAll(
            db.collection("users").document(uid)
                .snapshots()
                .map { snapshot ->
                    if (!snapshot.exists()) null
                    else snapshot.toObject(UserProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }
                .catch { error -> unwrapAndLogStreamError(error, OperationType.GET, path, uid) }
        )
    }

    suspend fun ensureUserProfile(
        userId: String,
        defaultName: String,
        email: String?
    ): Result<Unit> {
        val path = "users/$userId"
        return try {
            val uid = requireUserId(userId)
            val docRef = db.collection("users").document(uid)
            val snap = docRef.get().await()
            if (!snap.exists()) {
                val safeName = defaultName.trim().take(80).ifBlank { "Karigar User" }
                val payload = buildMap<String, Any> {
                    put("userId", uid)
                    put("displayName", safeName)
                    put("role", UserRole.UNSET.name)
                    if (!email.isNullOrBlank()) put("email", email.trim().take(120))
                    put("createdAt", FieldValue.serverTimestamp())
                    put("updatedAt", FieldValue.serverTimestamp())
                }
                docRef.set(payload).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun updateUserRole(userId: String, role: UserRole): Result<Unit> {
        val path = "users/$userId"
        return try {
            val uid = requireUserId(userId)
            val docRef = db.collection("users").document(uid)
            val snap = docRef.get().await()
            if (snap.exists()) {
                docRef.update(
                    mapOf(
                        "role" to role.name,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            } else {
                val user = auth.currentUser
                val safeName = (user?.displayName ?: "Karigar User").trim().take(80).ifBlank { "Karigar User" }
                val userEmail = user?.email?.trim()?.take(120)
                val payload = buildMap<String, Any> {
                    put("userId", uid)
                    put("displayName", safeName)
                    if (!userEmail.isNullOrBlank()) put("email", userEmail)
                    put("role", role.name)
                    put("createdAt", FieldValue.serverTimestamp())
                    put("updatedAt", FieldValue.serverTimestamp())
                }
                docRef.set(payload).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun saveCustomerProfile(
        userId: String,
        displayName: String,
        phone: String,
        town: String,
        address: String
    ): Result<Unit> {
        val path = "users/$userId"
        return try {
            val uid = requireUserId(userId)
            val cleanName = displayName.trim().take(80)
            val cleanPhone = phone.trim().take(25)
            val cleanTown = town.trim().take(60)
            val cleanAddress = address.trim().take(200)
            require(cleanName.isNotEmpty()) { "Please enter your name." }
            require(cleanPhone.length >= 7) { "Please enter a valid Phone / WhatsApp number." }

            val docRef = db.collection("users").document(uid)
            val snap = docRef.get().await()
            if (snap.exists()) {
                docRef.update(
                    mapOf(
                        "displayName" to cleanName,
                        "phone" to cleanPhone,
                        "town" to cleanTown,
                        "address" to cleanAddress,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            } else {
                val payload = buildMap<String, Any> {
                    put("userId", uid)
                    put("displayName", cleanName)
                    if (!auth.currentUser?.email.isNullOrBlank()) {
                        put("email", auth.currentUser!!.email!!.trim().take(120))
                    }
                    put("role", UserRole.CUSTOMER.name)
                    put("phone", cleanPhone)
                    put("town", cleanTown)
                    put("address", cleanAddress)
                    put("createdAt", FieldValue.serverTimestamp())
                    put("updatedAt", FieldValue.serverTimestamp())
                }
                docRef.set(payload).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    fun observeActiveKarigars(userId: String, category: String): Flow<List<KarigarProfile>> = flow {
        val uid = requireUserId(userId)
        val path = "karigars"
        emitAll(
            db.collection("karigars")
                .whereEqualTo("active", true)
                .whereEqualTo("category", category)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(KarigarProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.updatedAt ?: it.createdAt ?: Timestamp(0, 0) }
                }
                .catch { error -> unwrapAndLogStreamError(error, OperationType.LIST, path, uid) }
        )
    }

    suspend fun refreshActiveKarigars(userId: String, category: String): Result<List<KarigarProfile>> {
        val path = "karigars"
        return try {
            requireUserId(userId)
            val snapshot = db.collection("karigars")
                .whereEqualTo("active", true)
                .whereEqualTo("category", category)
                .get(Source.SERVER)
                .await()
            val list = snapshot.toObjects(KarigarProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                .sortedByDescending { it.updatedAt ?: it.createdAt ?: Timestamp(0, 0) }
            Result.success(list)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.LIST, path)
            Result.failure(e)
        }
    }

    fun observeMyKarigarProfile(userId: String): Flow<KarigarProfile?> = flow {
        val uid = requireUserId(userId)
        val path = "karigars/$uid"
        emitAll(
            db.collection("karigars").document(uid)
                .snapshots()
                .map { snapshot ->
                    if (!snapshot.exists()) null
                    else snapshot.toObject(KarigarProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }
                .catch { error -> unwrapAndLogStreamError(error, OperationType.GET, path, uid) }
        )
    }

    suspend fun saveKarigarProfile(
        userId: String,
        fullName: String,
        category: String,
        town: String,
        exactLocation: String,
        phone: String,
        rate: String,
        active: Boolean
    ): Result<Unit> {
        val path = "karigars/$userId"
        return try {
            val uid = requireUserId(userId)
            val cleanName = fullName.trim().take(80)
            val cleanLocation = exactLocation.trim().take(150)
            val cleanPhone = phone.trim().take(25)
            val cleanRate = rate.trim().take(60)

            require(cleanName.length >= 2) { "Full name must be at least 2 characters." }
            require(category in KarachiConstants.CATEGORY_NAMES) { "Please select a valid category." }
            require(town in KarachiConstants.KARACHI_TOWNS) { "Please select a valid Karachi town." }
            require(cleanLocation.length >= 2) { "Please enter your exact location / gali." }
            require(cleanPhone.length >= 7) { "Please enter a valid Phone / WhatsApp number." }
            require(cleanRate.length >= 2) { "Please enter your rate (e.g. Rs. 2500/day)." }

            val karigarRef = db.collection("karigars").document(uid)
            val userRef = db.collection("users").document(uid)
            val karigarSnap = karigarRef.get().await()
            val userSnap = userRef.get().await()
            val batch = db.batch()

            if (karigarSnap.exists()) {
                batch.update(
                    karigarRef,
                    mapOf(
                        "fullName" to cleanName,
                        "category" to category,
                        "town" to town,
                        "exactLocation" to cleanLocation,
                        "phone" to cleanPhone,
                        "rate" to cleanRate,
                        "active" to active,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            } else {
                batch.set(
                    karigarRef,
                    mapOf(
                        "ownerId" to uid,
                        "fullName" to cleanName,
                        "category" to category,
                        "town" to town,
                        "exactLocation" to cleanLocation,
                        "phone" to cleanPhone,
                        "rate" to cleanRate,
                        "active" to active,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }

            if (userSnap.exists()) {
                batch.update(
                    userRef,
                    mapOf(
                        "displayName" to cleanName,
                        "phone" to cleanPhone,
                        "town" to town,
                        "address" to cleanLocation,
                        "karigarCategory" to category,
                        "karigarRate" to cleanRate,
                        "karigarActive" to active,
                        "role" to UserRole.KARIGAR.name,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            } else {
                val userEmail = auth.currentUser?.email?.trim()?.take(120)
                val userPayload = buildMap<String, Any> {
                    put("userId", uid)
                    put("displayName", cleanName)
                    if (!userEmail.isNullOrBlank()) put("email", userEmail)
                    put("role", UserRole.KARIGAR.name)
                    put("phone", cleanPhone)
                    put("town", town)
                    put("address", cleanLocation)
                    put("karigarCategory", category)
                    put("karigarRate", cleanRate)
                    put("karigarActive", active)
                    put("createdAt", FieldValue.serverTimestamp())
                    put("updatedAt", FieldValue.serverTimestamp())
                }
                batch.set(userRef, userPayload)
            }

            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun toggleKarigarActive(userId: String, active: Boolean): Result<Unit> {
        val path = "karigars/$userId"
        return try {
            val uid = requireUserId(userId)
            val batch = db.batch()
            batch.update(
                db.collection("karigars").document(uid),
                mapOf(
                    "active" to active,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            val userRef = db.collection("users").document(uid)
            if (userRef.get().await().exists()) {
                batch.update(
                    userRef,
                    mapOf(
                        "karigarActive" to active,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    fun observeCustomerBookings(userId: String): Flow<List<BookingRequest>> = flow {
        val uid = requireUserId(userId)
        val path = "bookings"
        emitAll(
            db.collection("bookings")
                .whereEqualTo("customerId", uid)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(BookingRequest::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
                .catch { error -> unwrapAndLogStreamError(error, OperationType.LIST, path, uid) }
        )
    }

    fun observeKarigarBookings(userId: String): Flow<List<BookingRequest>> = flow {
        val uid = requireUserId(userId)
        val path = "bookings"
        emitAll(
            db.collection("bookings")
                .whereEqualTo("karigarId", uid)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(BookingRequest::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
                .catch { error -> unwrapAndLogStreamError(error, OperationType.LIST, path, uid) }
        )
    }

    suspend fun refreshBookingsForRole(userId: String, isKarigar: Boolean): Result<Unit> {
        val path = "bookings"
        return try {
            val uid = requireUserId(userId)
            val field = if (isKarigar) "karigarId" else "customerId"
            db.collection("bookings")
                .whereEqualTo(field, uid)
                .get(Source.SERVER)
                .await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.LIST, path)
            Result.failure(e)
        }
    }

    suspend fun createBooking(
        userId: String,
        karigar: KarigarProfile,
        customerName: String,
        customerPhone: String,
        customerArea: String,
        details: String
    ): Result<Unit> {
        var docPath = "bookings"
        return try {
            val uid = requireUserId(userId)
            val cleanCustomerName = customerName.trim().take(80)
            val cleanCustomerPhone = customerPhone.trim().take(25)
            val cleanCustomerArea = customerArea.trim().take(180)
            val cleanDetails = details.trim().take(400)

            require(karigar.id.isNotBlank()) { "Invalid Karigar listing." }
            require(cleanCustomerName.length >= 2) { "Customer name must be at least 2 characters." }
            require(cleanCustomerPhone.length >= 7) { "Please provide a valid Phone / WhatsApp number." }
            require(cleanCustomerArea.length >= 2) { "Please provide your Karachi area / address." }

            val docRef = db.collection("bookings").document()
            docPath = docRef.path
            val payload = buildMap<String, Any> {
                put("customerId", uid)
                put("karigarId", karigar.id)
                put("customerName", cleanCustomerName)
                put("customerPhone", cleanCustomerPhone)
                put("customerArea", cleanCustomerArea)
                put("karigarName", karigar.fullName.trim().take(80))
                put("karigarCategory", karigar.category)
                put("karigarTown", karigar.town)
                put("karigarPhone", karigar.phone.trim().take(25))
                put("karigarRate", karigar.rate.trim().take(60))
                if (cleanDetails.isNotEmpty()) put("details", cleanDetails)
                put("status", BookingStatus.PENDING.name)
                put("createdAt", FieldValue.serverTimestamp())
                put("updatedAt", FieldValue.serverTimestamp())
            }
            docRef.set(payload).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun updateBookingStatus(
        userId: String,
        bookingId: String,
        newStatus: BookingStatus
    ): Result<Unit> {
        val path = "bookings/$bookingId"
        return try {
            requireUserId(userId)
            require(bookingId.isNotBlank()) { "Invalid booking ID." }
            db.collection("bookings").document(bookingId)
                .update(
                    mapOf(
                        "status" to newStatus.name,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
                .await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }
}
