package com.example.model

import androidx.annotation.Keep
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AcUnit
import androidx.compose.material.icons.rounded.AirportShuttle
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Build
import androidx.compose.material.icons.rounded.Carpenter
import androidx.compose.material.icons.rounded.Construction
import androidx.compose.material.icons.rounded.DirectionsBus
import androidx.compose.material.icons.rounded.DirectionsCar
import androidx.compose.material.icons.rounded.FormatPaint
import androidx.compose.material.icons.rounded.GridView
import androidx.compose.material.icons.rounded.LocalShipping
import androidx.compose.material.icons.rounded.Plumbing
import androidx.compose.ui.graphics.vector.ImageVector
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

data class ServiceCategory(
    val name: String,
    val subtitle: String,
    val isTransport: Boolean,
    val icon: ImageVector
)

object KarachiConstants {
    val CATEGORIES: List<ServiceCategory> = listOf(
        ServiceCategory("Mistri", "Masonry & Construction", false, Icons.Rounded.Construction),
        ServiceCategory("Mazdoor", "Daily Labor & Helper", false, Icons.Rounded.Build),
        ServiceCategory("Plumber", "Pipes, Tank & Sanitary", false, Icons.Rounded.Plumbing),
        ServiceCategory("Electrician", "Wiring, UPS & Solar", false, Icons.Rounded.Bolt),
        ServiceCategory("Painter", "Interior & Exterior", false, Icons.Rounded.FormatPaint),
        ServiceCategory("Carpenter", "Woodwork & Furniture", false, Icons.Rounded.Carpenter),
        ServiceCategory("AC Technician", "Install, Gas & Repair", false, Icons.Rounded.AcUnit),
        ServiceCategory("Tile Fixer", "Marble, Tiles & Floor", false, Icons.Rounded.GridView),
        ServiceCategory("Shadi / Event Bus", "Wedding & Group Buses", true, Icons.Rounded.DirectionsBus),
        ServiceCategory("Long Route Coaster", "Intercity & Tours", true, Icons.Rounded.AirportShuttle),
        ServiceCategory("Car / Rent a Car", "Chauffeur & Self Drive", true, Icons.Rounded.DirectionsCar),
        ServiceCategory("Goods Delivery Truck", "Suzuki, Shehzore & Mazda", true, Icons.Rounded.LocalShipping)
    )

    val CATEGORY_NAMES: List<String> = CATEGORIES.map { it.name }

    val KARACHI_TOWNS: List<String> = listOf(
        "Baldia Town",
        "Orangi Town",
        "Gulshan-e-Iqbal",
        "Gulistan-e-Jauhar",
        "North Nazimabad",
        "DHA / Clifton",
        "Saddar / Lyari",
        "Korangi / Landhi",
        "Malir / Shah Faisal"
    )

    val AREA_FILTERS: List<String> = listOf("All Karachi") + KARACHI_TOWNS
}

enum class UserRole {
    UNSET,
    CUSTOMER,
    KARIGAR;

    companion object {
        fun fromRaw(raw: String?): UserRole =
            entries.firstOrNull { it.name.equals(raw, ignoreCase = true) } ?: UNSET
    }
}

enum class BookingStatus(val label: String) {
    PENDING("Pending"),
    ACCEPTED("Accepted"),
    COMPLETED("Completed"),
    DECLINED("Declined"),
    CANCELLED("Cancelled");

    companion object {
        fun fromRaw(raw: String?): BookingStatus =
            entries.firstOrNull { it.name.equals(raw, ignoreCase = true) } ?: PENDING
    }
}

@Keep
@IgnoreExtraProperties
data class UserProfile(
    @DocumentId val id: String = "",
    val userId: String = "",
    val displayName: String = "",
    val email: String = "",
    val role: String = UserRole.UNSET.name,
    val phone: String = "",
    val town: String = "",
    val address: String = "",
    val karigarCategory: String = "",
    val karigarRate: String = "",
    val karigarActive: Boolean = true,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    val parsedRole: UserRole
        get() = UserRole.fromRaw(role)

    val hasCompleteCustomerContact: Boolean
        get() = displayName.isNotBlank() && phone.trim().length >= 7 && (town.isNotBlank() || address.isNotBlank())
}

@Keep
@IgnoreExtraProperties
data class KarigarProfile(
    @DocumentId val id: String = "",
    val ownerId: String = "",
    val fullName: String = "",
    val category: String = "",
    val town: String = "",
    val exactLocation: String = "",
    val phone: String = "",
    val rate: String = "",
    val active: Boolean = true,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class BookingRequest(
    @DocumentId val id: String = "",
    val customerId: String = "",
    val karigarId: String = "",
    val customerName: String = "",
    val customerPhone: String = "",
    val customerArea: String = "",
    val karigarName: String = "",
    val karigarCategory: String = "",
    val karigarTown: String = "",
    val karigarPhone: String = "",
    val karigarRate: String = "",
    val details: String = "",
    val status: String = BookingStatus.PENDING.name,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    val parsedStatus: BookingStatus
        get() = BookingStatus.fromRaw(status)
}

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}
