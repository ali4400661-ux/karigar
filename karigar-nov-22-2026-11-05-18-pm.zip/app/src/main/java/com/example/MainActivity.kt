package com.example

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.data.KarigarRepository
import com.example.data.attemptAutoSignIn
import com.example.data.signOutWithCleanup
import com.example.model.UiState
import com.example.model.UserProfile
import com.example.model.UserRole
import com.example.ui.components.ErrorStateView
import com.example.ui.components.LoadingStateView
import com.example.ui.components.SignOutConfirmDialog
import com.example.ui.screens.CustomerShell
import com.example.ui.screens.KarigarShell
import com.example.ui.screens.LoginScreen
import com.example.ui.screens.RoleSelectionScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.theme.KarigarTheme
import com.example.ui.theme.MidnightBackground
import com.example.ui.viewmodel.KarigarViewModel
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT)
        )
        setContent {
            KarigarTheme {
                AppContent()
            }
        }
    }
}

@Composable
fun AppContent() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }

    var currentUser by remember { mutableStateOf(Firebase.auth.currentUser) }
    var splashComplete by remember { mutableStateOf(false) }

    DisposableEffect(Unit) {
        val listener = FirebaseAuth.AuthStateListener { auth ->
            currentUser = auth.currentUser
        }
        Firebase.auth.addAuthStateListener(listener)
        onDispose {
            Firebase.auth.removeAuthStateListener(listener)
        }
    }

    LaunchedEffect(Unit) {
        attemptAutoSignIn(
            context = context,
            credentialManager = credentialManager,
            onAuthSuccess = { currentUser = Firebase.auth.currentUser },
            onUnauthenticated = {},
            scope = scope
        )
        delay(850L)
        splashComplete = true
    }

    if (!splashComplete) {
        SplashScreen()
        return
    }

    val user = currentUser
    if (user == null) {
        LoginScreen(onLoginSuccess = { currentUser = Firebase.auth.currentUser })
    } else {
        key(user.uid) {
            AuthenticatedRoot(
                firebaseUser = user,
                onSignOutConfirmed = {
                    signOutWithCleanup(
                        credentialManager = credentialManager,
                        scope = scope,
                        onSignOutComplete = { currentUser = null }
                    )
                }
            )
        }
    }
}

@Composable
private fun AuthenticatedRoot(
    firebaseUser: FirebaseUser,
    onSignOutConfirmed: () -> Unit
) {
    val uid = firebaseUser.uid
    val defaultName = firebaseUser.displayName ?: "Karigar User"
    val defaultEmail = firebaseUser.email

    val viewModel: KarigarViewModel = viewModel(
        key = uid,
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY]) {
                    "APPLICATION_KEY missing from CreationExtras"
                }
                val repo = KarigarRepository(app)
                KarigarViewModel(
                    repository = repo,
                    currentUserId = uid,
                    initialDisplayName = defaultName,
                    initialEmail = defaultEmail
                )
            }
        }
    )

    val userProfileState by viewModel.userProfileState.collectAsStateWithLifecycle()
    val actionInProgress by viewModel.actionInProgress.collectAsStateWithLifecycle()
    val snackbarMessage by viewModel.snackbarMessage.collectAsStateWithLifecycle()

    var showRoleSelector by remember(uid) { mutableStateOf(false) }
    var showSignOutDialog by remember { mutableStateOf(false) }

    when (val state = userProfileState) {
        is UiState.Loading -> {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MidnightBackground)
            ) {
                LoadingStateView("Loading your Karigar account...")
            }
        }
        is UiState.Error -> {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MidnightBackground)
                    .padding(20.dp)
            ) {
                ErrorStateView(
                    message = state.message,
                    onRetry = { viewModel.selectRole(UserRole.UNSET) }
                )
            }
        }
        is UiState.Success -> {
            val profile = state.data ?: UserProfile(
                userId = uid,
                displayName = defaultName,
                email = defaultEmail.orEmpty(),
                role = UserRole.UNSET.name
            )
            val activeRole = profile.parsedRole

            if (activeRole == UserRole.UNSET || showRoleSelector) {
                RoleSelectionScreen(
                    userName = profile.displayName.ifBlank { defaultName },
                    userEmail = profile.email.ifBlank { defaultEmail },
                    currentRole = activeRole,
                    canNavigateBack = activeRole != UserRole.UNSET,
                    isUpdating = actionInProgress,
                    errorMessage = snackbarMessage,
                    onSelectRole = { chosenRole ->
                        viewModel.clearSnackbar()
                        if (chosenRole == activeRole && activeRole != UserRole.UNSET) {
                            showRoleSelector = false
                        } else {
                            viewModel.selectRole(chosenRole) {
                                showRoleSelector = false
                            }
                        }
                    },
                    onBack = {
                        viewModel.clearSnackbar()
                        showRoleSelector = false
                    },
                    onSignOutClick = { showSignOutDialog = true }
                )
            } else if (activeRole == UserRole.CUSTOMER) {
                CustomerShell(
                    viewModel = viewModel,
                    userProfile = profile,
                    onSwitchRole = { showRoleSelector = true },
                    onSignOutClick = { showSignOutDialog = true }
                )
            } else {
                KarigarShell(
                    viewModel = viewModel,
                    userProfile = profile,
                    onSwitchRole = { showRoleSelector = true },
                    onSignOutClick = { showSignOutDialog = true }
                )
            }
        }
    }

    if (showSignOutDialog) {
        SignOutConfirmDialog(
            onConfirm = {
                showSignOutDialog = false
                onSignOutConfirmed()
            },
            onDismiss = { showSignOutDialog = false }
        )
    }
}
